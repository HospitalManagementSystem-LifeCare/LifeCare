package com.app.pojos;

public enum UserValidity {
	INACTIVE,ACTIVE
}
