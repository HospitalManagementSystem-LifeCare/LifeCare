package com.app.pojos;

public enum Gender {
	M,F,O
}
