package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ServiceDTO;
import com.app.service.ServiceService;

@RestController
@RequestMapping("/hospitalservice")
@CrossOrigin("http://localhost:3000")
public class ServiceController {
	
	@Autowired
	private ServiceService serviceservice;
	
	@GetMapping("/showAll")
	public ResponseEntity<?> getAllServices(){	
		System.out.println("hello");
		System.out.println("abcd"+serviceservice.getServices());
		return ResponseEntity.ok(serviceservice.getServices());
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> addNewService(@RequestBody ServiceDTO service ){
		serviceservice.addNewService(service);
		return ResponseEntity.status(HttpStatus.CREATED).body(service);
	}
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteService(@PathVariable Integer id){
		return ResponseEntity.ok(serviceservice.deleteService(id));
	}
}
