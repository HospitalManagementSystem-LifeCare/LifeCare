package com.app.service;

import java.util.List;



import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.ServiceDao;
import com.app.dto.ServiceDTO;

@Service
@Transactional
@CrossOrigin
public class ServiceServiceImpl implements ServiceService {
	@Autowired
	private ServiceDao servicedao;
	
	@Autowired
	ModelMapper mp ;

	@Override
	public List<com.app.pojos.Service> getServices() {
		System.out.println("abcd");
		List<com.app.pojos.Service> li= servicedao.findAll();
		System.out.println("aaaaa"+li);
	return li;
	}
	
	@Override
	public void addNewService(ServiceDTO service) {
		// TODO Auto-generated method stub
		com.app.pojos.Service ser = mp.map(service,com.app.pojos.Service.class);
		servicedao.save(ser);
		
		
	}
@Override
public String deleteService(Integer id) {
	com.app.pojos.Service ser = servicedao.findById(id).orElseThrow(()->new ResourceNotFoundException("no such service available"));
	servicedao.delete(ser);
	return "Service deleted ";
}
//	@Override
//	public 	List<Servicee> getServices(){
//		System.out.println("abcd");
//		List<Servicee> li= servicedao.findAll();
//		System.out.println("aaaaa"+li);
//		return li;
//	}

}
