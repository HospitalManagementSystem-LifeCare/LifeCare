package com.app.service;

import java.util.List;

import com.app.dto.ServiceDTO;
import com.app.pojos.Service;

public interface ServiceService {
	
	List<Service> getServices();

	void addNewService(ServiceDTO service);

	String deleteService(Integer id);

}
