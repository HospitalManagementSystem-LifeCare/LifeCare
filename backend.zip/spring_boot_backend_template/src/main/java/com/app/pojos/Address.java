package com.app.pojos;

import javax.persistence.*;

@Entity
public class Address extends BaseEntity {
   

    private String street;
    private String city;
    private String state;
    private String postalCode;
    private String country;

    // Constructors, getters, and setters
}
