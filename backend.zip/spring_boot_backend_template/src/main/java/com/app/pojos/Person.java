package com.app.pojos;

import java.time.LocalDate;


import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;


@MappedSuperclass
public class Person extends BaseEntity {
	private String name;
	@Enumerated(EnumType.STRING)
	private Gender gender;
	@OneToOne()
	private Address address;
	private LocalDate dob;
	private String email;
	private String contactNo;
	
	
}
