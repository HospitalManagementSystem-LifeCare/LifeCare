package com.app.pojos;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Table;

@Entity
@javax.persistence.Table(name = "doctor")
public class Doctor extends Person {
	private String qualification;
//	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	private List<Patient> li;
	@OneToMany(mappedBy = "doctor", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Patient> patients;

	@OneToMany(mappedBy = "doctor", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Appointment> appointments = new HashSet<>();
	
}
