package com.app.pojos;

import java.time.LocalDate;

import javax.persistence.Entity;

import javax.persistence.ManyToOne;


@Entity
public class MedicalRecord extends BaseEntity {
   
    @ManyToOne
    private Patient patient;
    @ManyToOne
    private Doctor doctor;
    private LocalDate dateOfRecord;
    private String diagnosis;
    // other attributes, getters and setters
}