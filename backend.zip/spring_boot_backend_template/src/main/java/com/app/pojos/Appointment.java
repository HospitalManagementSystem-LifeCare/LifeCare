package com.app.pojos;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Appointment  extends BaseEntity {
   
    @ManyToOne
    private Patient patient;
    @ManyToOne
    private Doctor doctor;
    private LocalDateTime appointmentDateTime;
    private String reason;
    private String status;
    // other attributes, getters and setters
}